﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CHashLab4Aplikacja
{

    public partial class Form1 : Form
    {
        class Rectangle
        {
            public void drawRec(Graphics g, Pen pen, int startX, int startY, int endY, int endX)
            {
                g.DrawLine(pen, new Point(startX, startY), new Point(endX, startY));
                g.DrawLine(pen, new Point(endX, startY), new Point(endX, endY));
                g.DrawLine(pen, new Point(endX, endY), new Point(startX, endY));
                g.DrawLine(pen, new Point(startX, endY), new Point(startX, startY));
            }
        }
        class Circle
        {
            float radius;
            double temp;
            public void drawCir(Graphics g, Pen pen, int startX, int startY, int endY, int endX)
            {
                temp = Math.Sqrt(Math.Pow((startX - endX), 2) + Math.Pow((startY - endY), 2));
                radius = Math.Abs((float)temp);
                g.DrawEllipse(pen, startX - radius, startY - radius, radius + radius, radius + radius);
            }
        }
        class Line
        {
            public void drawLine(Graphics g, Pen pen, int startX, int startY, int endY, int endX)
            {
                g.DrawLine(pen, new Point(startX, startY), new Point(endX, endY));
            }
        }

        Graphics g;
        int posX = -1, posY = -1;
        bool move = false, lineB = false, circleB = false, rectangleB = false, freeB = false;
        Pen pen;
        Line line = new Line();
        Rectangle rectangle = new Rectangle();
        Circle circle = new Circle();
        int sX = 0, sY = 0, eX = 0, eY = 0;

        public Form1()
        {
            InitializeComponent();
            g = panel1.CreateGraphics();
            pen = new Pen(Color.Black, 5);
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            PictureBox p = (PictureBox)sender;
            pen.Color = p.BackColor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            rectangleB = true;
            circleB = false;
            lineB = false;
            freeB = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            circleB = true;
            rectangleB = false;
            lineB = false;
            freeB = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lineB = true;
            rectangleB = false;
            circleB = false;
            freeB = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            freeB = true;
            rectangleB = false;
            circleB = false;
            lineB = false;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            move = true;
            posX = e.X;
            posY = e.Y;
            sX = e.X;
            sY = e.Y;
            panel1.Cursor = Cursors.Cross;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if(move && posX != -1 && posY != -1)
            {
                if (freeB)
                {
                    g.DrawLine(pen, new Point(posX, posY), e.Location);
                }
                posX = e.X;
                posY = e.Y;
            }
        }

        public void panel1_Paint(object sender, PaintEventArgs e)
        {
            if (lineB)
            {
                line.drawLine(g, pen, sX, sY, eY, eX);
            }
            else if (rectangleB)
            {
                rectangle.drawRec(g, pen, sX, sY, eY, eX);
            }
            else if (circleB)
            {
                circle.drawCir(g, pen, sX, sY, eY, eX);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            eX = e.X;
            eY = e.Y;
            move = false;
            posX = -1;
            posY = -1;
            panel1.Cursor = Cursors.Default;
            panel1_Paint(this, null);
        }
    }
}
