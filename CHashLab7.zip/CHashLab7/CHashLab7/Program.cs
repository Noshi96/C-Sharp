﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace CHashLab7
{
    class Program
    {
        static string res = "", inPath = "", outPath = "";
        static int posOfX = 0, width = 0, height = 0;
        static List<string> fileNamesList = new List<string>();
        static List<string> imagesNameList = new List<string>();
        static List<string> extensionList = new List<string>();
        static List<Image> imageList = new List<Image>();

        public static Bitmap ResizeImage(Image image, int width, int height)
        {
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }
            return destImage;
        }

        public static void findNames(string path, List<string> list)
        {
            string[] filleEntries = Directory.GetFiles(path);
            foreach (string filename in filleEntries)
            {
                list.Add(filename);
            }
        }

        public static List<Image> getImages()
        {
            List<Image> imageList = new List<Image>();
            string extension = "", imageFileName="";
            foreach (string name in fileNamesList)
            {
                extension = Path.GetExtension(name);
                imageFileName = Path.GetFileNameWithoutExtension(name);

                if (extension == ".bmp" || extension == ".png" || extension == ".jpg")
                {
                    imageList.Add(Image.FromFile(name));
                    imagesNameList.Add(imageFileName);
                    extensionList.Add(extension);
                }
            }
            return imageList;
        }

        public static void saveImage(string destPath)
        {
            for(int i=0; i < imageList.Count(); i++)
            {
                int ite = 1;
                while(System.IO.File.Exists(destPath + imagesNameList[i] + "_" + ite + extensionList[i]))
                    ite++;

                if (System.IO.File.Exists(destPath + imagesNameList[i] + extensionList[i]))
                {                  
                    ResizeImage(imageList[i], width, height).Save(destPath + imagesNameList[i] + "_" + ite + extensionList[i]);
                }
                else
                {
                    ResizeImage(imageList[i], width, height).Save(destPath + imagesNameList[i] + extensionList[i]);
                }
            }
        }

        static void Main(string[] args)
        {
            if (args.Count()==3)
            {
                res = args[0];
                inPath = args[1];
                outPath = args[2];
            }
            else if (args.Count()==2)
            {
                res = args[0];
                inPath = args[1];
            }
            else if (args.Count() == 1)
            {
                res = args[0];
                inPath = System.AppDomain.CurrentDomain.BaseDirectory;
            }
            else
            {
                Console.WriteLine("Nie podałeś żadnego parametru");
                return;
            }

            posOfX = res.IndexOf('x');
            width = Int32.Parse(res.Substring(0, posOfX));
            height = Int32.Parse(res.Substring(posOfX+1));
            inPath = inPath.Replace("-inputdir=","");
            outPath = outPath.Replace("-outputdir=","");

            if (Directory.Exists(outPath))
            {
                findNames(inPath, fileNamesList);
                imageList = getImages();
                saveImage(outPath);
            }
            else
            {
                findNames(inPath, fileNamesList);
                imageList = getImages();
                if (outPath == "")
                {
                    DirectoryInfo di = Directory.CreateDirectory(inPath + "images");
                    saveImage(inPath + @"images\");
                }
                else
                {
                    DirectoryInfo di = Directory.CreateDirectory(outPath);
                    saveImage(outPath);
                }
            }
        }
    }
}
