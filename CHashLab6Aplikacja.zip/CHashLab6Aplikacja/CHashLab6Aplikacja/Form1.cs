﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CHashLab6Aplikacja
{
    public partial class Form1 : Form
    {
        List<string> listOfNames = new List<string>();
        Dictionary<string, string> dictionaryTwo = new Dictionary<string, string>();
        Dictionary<string, string> dictionaryThree = new Dictionary<string, string>();
        string path = "nazwiska.txt";

        bool canUpdate = true;
        bool needUpdate = true;

        public Form1()
        {
            InitializeComponent();
            loadToDictionary(path);
        }

        private void loadToDictionary(string path)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            foreach (string line in File.ReadAllLines(path))
            {
                listOfNames.Add(line.Remove(0, line.IndexOf(' ') + 1));
            }
            watch.Stop();
            label2.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
        }

        private void loadTwoCharsDictionary()
        {
            comboBox1.Items.Clear();
            foreach (KeyValuePair<string, string> entry in dictionaryTwo)
            {
                comboBox1.Items.Add(entry.Key);
                comboBox1.DroppedDown = true;
            }
            dictionaryTwo.Clear();
        }

        private void loadThreeCharsDictionary()
        {
            comboBox1.Items.Clear();
            foreach (KeyValuePair<string, string> entry in dictionaryThree)
            {
                comboBox1.Items.Add(entry.Key);
                comboBox1.DroppedDown = true;
            }
            dictionaryThree.Clear();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            needUpdate = false;
        }

        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
            needUpdate = true;
        }

        private void restartTimer()
        {
            timer1.Stop();
            canUpdate = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            canUpdate = true;
            timer1.Stop();
            updateData();
        }

        private void updateData()
        {
            if(comboBox1.Text.Length == 2)
            {
                var watch = System.Diagnostics.Stopwatch.StartNew();
                for (int i = 0; i < listOfNames.Count; i++)
                {
                    if (listOfNames[i].Contains(comboBox1.Text))
                    {
                        if (!dictionaryTwo.ContainsKey(listOfNames[i]))
                            dictionaryTwo.Add(listOfNames[i], i.ToString());
                    }
                }                
                watch.Stop();
                label4.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
                loadTwoCharsDictionary();
            }
            if(comboBox1.Text.Length == 3)
            {
                var watch = System.Diagnostics.Stopwatch.StartNew();
                for (int i = 0; i < listOfNames.Count; i++)
                {
                    if (listOfNames[i].Contains(comboBox1.Text))
                    {
                        if (!dictionaryThree.ContainsKey(listOfNames[i]))
                            dictionaryThree.Add(listOfNames[i], i.ToString());
                    }
                }
                watch.Stop();
                label6.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
                loadThreeCharsDictionary();
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (needUpdate)
            {
                if (canUpdate)
                {
                    canUpdate = false;
                    updateData();                  
                }
                else
                {
                    restartTimer();
                }
            }
            if(comboBox1.Text != null)
            {
                comboBox1.Select(comboBox1.Text.Length, 0);
            }
        }

    }
}
