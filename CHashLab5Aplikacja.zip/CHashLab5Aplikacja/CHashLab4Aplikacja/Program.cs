﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EasyTabs;

namespace CHashLab4Aplikacja
{
    static class Program
    {
        /// <summary>
        /// Główny punkt wejścia dla aplikacji.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            App app = new App();

            app.Tabs.Add( 
                new TitleBarTab(app)
                {
                    Content = new Form1
                    {
                        Text = "New tab"
                    }
                }
             );

            app.SelectedTabIndex = 0;

            TitleBarTabsApplicationContext titleBarTabsApplicationContext = new TitleBarTabsApplicationContext();
            titleBarTabsApplicationContext.Start(app);
            Application.Run(titleBarTabsApplicationContext);

        }
    }
}
