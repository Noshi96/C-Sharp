﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EasyTabs;

namespace CHashLab4Aplikacja
{

    public partial class Form1 : Form
    {
        protected TitleBarTabs ParentTabs
        {
            get
            {
                return (ParentForm as TitleBarTabs);
            }
        }
        class Figure
        {
            virtual public void draw(Graphics g, Pen pen, int startX, int startY, int endY, int endX, int pX, int pY, Bitmap bmp)
            {

            }
        }
        class Rectangle : Figure
        {
            override public void draw(Graphics g, Pen pen, int startX, int startY, int endY, int endX, int pX, int pY, Bitmap bmp)
            {
                g.DrawLine(pen, new Point(startX, startY), new Point(endX, startY));
                g.DrawLine(pen, new Point(endX, startY), new Point(endX, endY));
                g.DrawLine(pen, new Point(endX, endY), new Point(startX, endY));
                g.DrawLine(pen, new Point(startX, endY), new Point(startX, startY));
                g = Graphics.FromImage(bmp);
                g.DrawLine(pen, new Point(startX, startY), new Point(endX, startY));
                g.DrawLine(pen, new Point(endX, startY), new Point(endX, endY));
                g.DrawLine(pen, new Point(endX, endY), new Point(startX, endY));
                g.DrawLine(pen, new Point(startX, endY), new Point(startX, startY));
            }
        }
        class Circle : Figure
        {
            float radius;
            double temp;
            override public void draw(Graphics g, Pen pen, int startX, int startY, int endY, int endX, int pX, int pY, Bitmap bmp)
            {
                temp = Math.Sqrt(Math.Pow((startX - endX), 2) + Math.Pow((startY - endY), 2));
                radius = Math.Abs((float)temp);
                g.DrawEllipse(pen, startX - radius, startY - radius, radius + radius, radius + radius);
                g = Graphics.FromImage(bmp);
                temp = Math.Sqrt(Math.Pow((startX - endX), 2) + Math.Pow((startY - endY), 2));
                radius = Math.Abs((float)temp);
                g.DrawEllipse(pen, startX - radius, startY - radius, radius + radius, radius + radius);
            }
        }
        class Line : Figure
        {
            override public void draw(Graphics g, Pen pen, int startX, int startY, int endY, int endX, int pX, int pY, Bitmap bmp)
            {
                g.DrawLine(pen, new Point(startX, startY), new Point(endX, endY));
                g = Graphics.FromImage(bmp);
                g.DrawLine(pen, new Point(startX, startY), new Point(endX, endY));
            }
        }
        class Free : Figure
        {
            override public void draw(Graphics g, Pen pen, int startX, int startY, int endY, int endX, int pX, int pY, Bitmap bmp)
            {
                g.DrawLine(pen, new Point(pX, pY), new Point(pX + 1, pY + 1));
                g.DrawLine(pen, new Point(pX, pY), new Point(pX - 1, pY + 1));
                g.DrawLine(pen, new Point(pX, pY), new Point(pX + 1, pY - 1));
                g.DrawLine(pen, new Point(pX, pY), new Point(pX - 1, pY - 1));
                g = Graphics.FromImage(bmp);
                g.DrawLine(pen, new Point(pX, pY), new Point(pX + 1, pY + 1));
                g.DrawLine(pen, new Point(pX, pY), new Point(pX - 1, pY + 1));
                g.DrawLine(pen, new Point(pX, pY), new Point(pX + 1, pY - 1));
                g.DrawLine(pen, new Point(pX, pY), new Point(pX - 1, pY - 1));
            }
        }



        Graphics g;
        Bitmap bmp;
        int posX = -1, posY = -1;
        bool move = false, freeB = false;
        Pen pen;
        int sX = 0, sY = 0, eX = 0, eY = 0;
        Figure figure = new Figure();


        private void Save(string fileName, ImageFormat format)
        {
                bmp.Save(fileName,format);
        }

        private void LoadImage(string path) {
            panel1.BackgroundImage = Image.FromFile(path);
            bmp = (Bitmap)panel1.BackgroundImage;
        }

        public Form1()
        {
            InitializeComponent();
            g = panel1.CreateGraphics();
            pen = new Pen(Color.Black, 5);
            bmp = new Bitmap(panel1.ClientSize.Width, panel1.ClientSize.Height);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            PictureBox p = (PictureBox)sender;
            pen.Color = p.BackColor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            figure = new Rectangle();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            figure = new Circle();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            figure = new Line();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Images|*.png;*.bmp;*.jpg";
            ImageFormat format = ImageFormat.Png;
            if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string ext = System.IO.Path.GetExtension(sfd.FileName);
                switch (ext)
                {
                    case ".jpg":
                        format = ImageFormat.Jpeg;
                        break;
                    case ".bmp":
                        format = ImageFormat.Bmp;
                        break;
                    case ".png":
                        format = ImageFormat.Png;
                        break;
                }
                Save(sfd.FileName, format);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            String filePath = string.Empty;
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filePath = openFileDialog.FileName;                  
                }
                LoadImage(filePath);
            }       
        }

        private void button4_Click(object sender, EventArgs e)
        {
            figure = new Free();
            freeB = true;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            move = true;
            posX = e.X;
            posY = e.Y;
            sX = e.X;
            sY = e.Y;
            panel1.Cursor = Cursors.Cross;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            panel1.BackgroundImage = bmp;
            if(move && posX != -1 && posY != -1)
            {
                if (freeB)
                {
                    panel1_Paint(this, null);
                }
                posX = e.X;
                posY = e.Y;            
            }
        }

        public void panel1_Paint(object sender, PaintEventArgs e)
        {
            figure.draw(g, pen, sX, sY, eY, eX, posX, posY, bmp);
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            eX = e.X;
            eY = e.Y;
            move = false;
            posX = -1;
            posY = -1;
            panel1.Cursor = Cursors.Default;
            panel1_Paint(this, null);
            freeB = false;
        }
    }
}
