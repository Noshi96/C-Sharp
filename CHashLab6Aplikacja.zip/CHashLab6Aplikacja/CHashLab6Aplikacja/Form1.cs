﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CHashLab6Aplikacja
{
    public partial class Form1 : Form
    {
        List<string> listOfNames = new List<string>();
        Dictionary<string, List<string>> dictionaryTwo = new Dictionary<string, List<string>>();
        Dictionary<string, List<string>> dictionaryThree = new Dictionary<string, List<string>>();
        string path = "nazwiska.txt";

        bool canUpdate = true;
        bool needUpdate = true;

        public Form1()
        {
            InitializeComponent();
            loadToDictionary(path);
            loadTwoCharsDictionary(listOfNames);
            loadThreeCharsDictionary(listOfNames);
        }

        private void loadToDictionary(string path)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            foreach (string line in File.ReadAllLines(path))
            {
                listOfNames.Add(line.Remove(0, line.IndexOf(' ') + 1));
            }
            watch.Stop();
            label2.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
        }

        private void loadTwoCharsDictionary(List<string> lista)
        {
            
            var watch = System.Diagnostics.Stopwatch.StartNew();
            foreach (string name in lista)
            {
                string shortName = String.Empty;
                if (name.Count() >= 2)
                {
                    shortName = name[0].ToString() + name[1].ToString();
                    List<string> value;
                    if (dictionaryTwo.TryGetValue(shortName, out value))
                    {
                        dictionaryTwo[shortName] = value;
                        value.Add(name);
                    }
                    else if (!dictionaryTwo.ContainsKey(shortName))
                    {
                        dictionaryTwo.Add(shortName, new List<string> { name });
                    }
                }
            }
            watch.Stop();
            label4.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
        }

        private void loadThreeCharsDictionary(List<string> lista)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            foreach (string name in lista)
            {
                string shortName = String.Empty;
                
                if (name.Count() >= 3)
                {
                    shortName = name[0].ToString() + name[1].ToString() + name[2].ToString();
                    List<string> value;
                    if (dictionaryThree.TryGetValue(shortName, out value))
                    {
                        dictionaryThree[shortName] = value;
                        value.Add(name);
                    }
                    else if (!dictionaryThree.ContainsKey(shortName))
                    {
                        dictionaryThree.Add(shortName, new List<string> { name });
                    }
                }
            }
            watch.Stop();
            label6.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            needUpdate = false;
        }

        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
            needUpdate = true;
        }

        private void restartTimer()
        {
            timer1.Stop();
            canUpdate = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            canUpdate = true;
            timer1.Stop();
            updateData();
        }

        private void updateData()
        {
            if(comboBox1.Text.Length == 2)
            {
                comboBox1.Items.Clear();
                string shortName = comboBox1.Text[0].ToString().ToUpper() + comboBox1.Text[1].ToString();
                //var watch = System.Diagnostics.Stopwatch.StartNew();

                List<string> value;
                if (dictionaryTwo.TryGetValue(shortName, out value))
                {
                    dictionaryTwo[shortName] = value;
                    comboBox1.Items.AddRange(value.ToArray());
                    comboBox1.DroppedDown = true;
                }               
                //watch.Stop();
                //label4.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
            }

            if(comboBox1.Text.Length == 3)
            {               
                comboBox1.Items.Clear();
                string shortName = comboBox1.Text[0].ToString().ToUpper() + comboBox1.Text[1].ToString() + comboBox1.Text[2].ToString();
                //var watch = System.Diagnostics.Stopwatch.StartNew();

                List<string> value;
                if (dictionaryThree.TryGetValue(shortName, out value))
                {
                    dictionaryThree[shortName] = value;
                    comboBox1.Items.AddRange(value.ToArray());
                    comboBox1.DroppedDown = true;
                }               
                //watch.Stop();
                //label6.Text = watch.ElapsedMilliseconds.ToString() + " milisekund";
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (needUpdate)
            {
                if (canUpdate)
                {
                    canUpdate = false;
                    updateData();                  
                }
                else
                {
                    restartTimer();
                }
            }
            if(comboBox1.Text != null)
            {
                comboBox1.Select(comboBox1.Text.Length, 0);
            }
        }

    }
}
